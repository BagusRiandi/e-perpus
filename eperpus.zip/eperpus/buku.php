<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-Perpus</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <link href="css/dashboard.css" rel="stylesheet">
</head>
<body>
    <header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 text-center" href="dashboard.html">e-Perpus</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-nav">
          <div class="nav-item text-nowrap">
          </div>
        </div>
    </header>

    <div class="container-fluid">
        <div class="row">

          <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
              <ul class="nav flex-column">
                <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="dashboardadmin.php">
                    <span class="bi bi-house" style="margin-right: 10px;"></span>
                    <span>Beranda</span>
                  </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="buku.php">
                      <span class="bi bi-book" style="margin-right: 10px;"></span>
                      <span>Buku</span>
                    </a>
                    </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="buku.php">
                      <span class="bi bi-box-arrow-right" style="margin-right: 10px;"></span>
                      <span>Keluar</span>
                    </a>
                </li>
              </ul>
            </div>
          </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
          <h4 class="h2">Form Inputan Data Buku</h4>
          <div class="btn-toolbar mb-2 mb-md-0"></div>
      </div>
      <form action="" method="POST">
        <div class="container">
          <div class="col-md-6 mb-3">
            <h6 for="judul_buku" class="form-label">Judul Buku</h6>
            <input type="text" class="form-control" name="judul_buku" placeholder="Masukkan judul buku">
          </div>
          <div class="col-md-6 mb-3">
            <h6 for="rak_buku" class="form-label">Rak Buku</h6>
            <input type="number" class="form-control" name="rak_buku" placeholder="Masukkan rak buku">
          </div>
          <div class="col-md-6 mb-3">
            <h6 for="penerbit" class="form-label">Penerbit</h6>
            <input type="text" class="form-control" name="penerbit" placeholder="Masukkan nama penerbit">
          </div>
          <div class="col-md-6 mb-3">
            <h6 for="tahun_terbit" class="form-label">Tahun Terbit</h6>
            <input type="number" class="form-control" name="tahun_terbit" placeholder="Masukkan tahun terbit">
          </div>

          <input class="btn btn-primary btn-lg w-50" type="submit" name="simpan" value="SIMPAN" />  
        </div>
      </form>
  </main>
    
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
</body>
</html>