<?php
require_once 'config.php';

if (isset($_POST['simpan'])) {
    $judul_buku = $_POST['judul_buku'];
	$rak_buku = $_POST['rak_buku'];
    $penerbit =$_POST['penerbit'];
    $tahun_terbit =$_POST['tahun_terbit'];

	$sql = "SELECT * FROM tbl_buku WHERE judul_buku='$judul_buku',rak_buku='$rak_buku',penerbit='$penerbit',tahun_terbit='$tahun_terbit'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
        $_SESSION['start'] = $row['start'];
	} else {
		echo "<script>alert('Woops! Email Atau Password anda Salah.')</script>";
	}
}
